package classRelationships;

public class classRelationships {
    // class utama (tidak digunakan langsung, hanya agar ada 1 public class)
}


class Person {
    protected String name; // atribut nama

    // constructor untuk mengisi nama
    public Person(String name) {
        this.name = name;
    }

    // method untuk mengambil nama
    public String getName() {
        return name;
    }
}


class Employee extends Person {

    // constructor memanggil constructor superclass
    public Employee(String name) {
        super(name);
    }
}


class Manager extends Employee {

    private Task task; // Manager memiliki task

    public Manager(String name) {
        super(name);
    }

    // method untuk menambahkan task ke manager
    public void setTask(Task task) {
        this.task = task;
    }

    // mengambil nama task
    public String getTaskName() {
        return task.getTaskName();
    }
}

class Project {

    private String projectName;
    private Employee leader; // project memiliki leader (employee)

    // constructor project
    public Project(String projectName, Employee leader) {
        this.projectName = projectName;
        this.leader = leader;
    }

    // mengambil nama leader project
    public String getLeaderName() {
        return leader.getName();
    }
}


class Department {

    private String departmentName;
    private Manager manager; // department memiliki manager

    public Department(String departmentName) {
        this.departmentName = departmentName;
    }

    // menetapkan manager untuk department
    public void setManager(Manager manager) {
        this.manager = manager;
    }

    // mengambil nama manager
    public String getManagerName() {
        return manager.getName();
    }
}


class Task {

    private String taskName; // nama tugas

    // constructor task
    public Task(String taskName) {
        this.taskName = taskName;
    }

    // mengambil nama task
    public String getTaskName() {
        return taskName;
    }
}